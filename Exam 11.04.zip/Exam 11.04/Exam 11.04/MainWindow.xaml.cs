﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAnimatedGif;

namespace Exam_11._04
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            
            InitializeComponent();
        }

        double result = 0;

        /**********************************
Nazwa funkcji: Plus
Opis funkcji: Wykonuje działanie dodawania
Parametry: sender - Obiekt, który wywołał zdarzenie kliknięcia przycisku. e - Argumenty zdarzenia kliknięcia przycisku.
Zwracany typ i opis: void - Metoda nie zwraca żadnej wartości.
Autor: Patryk Krzyszczyk
***********************************/

        private void Plus(object sender, RoutedEventArgs e)
        {
            pole.Text += $"{result} + {Zmienna.Text}\n";
            result += double.Parse(Zmienna.Text);
            RESULT.Content = result;
        }

        /**********************************
Nazwa funkcji: Minus
Opis funkcji: Wykonuje działanie odejmowania
Parametry: sender - Obiekt, który wywołał zdarzenie kliknięcia przycisku. e - Argumenty zdarzenia kliknięcia przycisku.
Zwracany typ i opis: void - Metoda nie zwraca żadnej wartości.
Autor: Patryk Krzyszczyk
***********************************/
        private void Minus(object sender, RoutedEventArgs e)
        {
            pole.Text += $"{result} - {Zmienna.Text}\n";
            result -= double.Parse(Zmienna.Text);
            RESULT.Content = result;
        }

        /**********************************
Nazwa funkcji: Substract
Opis funkcji: Wykonuje działanie mnożenia
Parametry: sender - Obiekt, który wywołał zdarzenie kliknięcia przycisku. e - Argumenty zdarzenia kliknięcia przycisku.
Zwracany typ i opis: void - Metoda nie zwraca żadnej wartości.
Autor: Patryk Krzyszczyk
***********************************/
        private void Substract(object sender, RoutedEventArgs e)
        {
            pole.Text += $"{result} * {Zmienna.Text}\n";
            result *= double.Parse(Zmienna.Text);
            RESULT.Content = result;
        }
        /**********************************
Nazwa funkcji: Divide
Opis funkcji: Wykonuje działanie dzielenia
Parametry: sender - Obiekt, który wywołał zdarzenie kliknięcia przycisku. e - Argumenty zdarzenia kliknięcia przycisku.
Zwracany typ i opis: void - Metoda nie zwraca żadnej wartości.
Autor: Patryk Krzyszczyk
***********************************/
        private void Divide(object sender, RoutedEventArgs e)
        {
            pole.Text += $"{result} / {Zmienna.Text}\n";
            result /= double.Parse(Zmienna.Text);
            RESULT.Content = result;
        }

        private void Make(object sender, RoutedEventArgs e)
        {
            Uri resourceUri = new Uri("/icegif-162.gif", UriKind.Relative);
            var image = new BitmapImage();
            image.BeginInit();
            image.UriSource = resourceUri;
            image.EndInit();
            ImageBehavior.SetAnimatedSource(Ric, image);
        }
    }
}
 